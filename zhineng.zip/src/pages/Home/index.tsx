const menu = {
  path: '/',
  exact: true,
  name: '首页',
  component: require('./Home'),
  icon: 'home',
};

export default menu;
