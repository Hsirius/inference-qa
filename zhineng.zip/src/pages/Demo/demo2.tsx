import React from 'react';

export default () => {
  return <div>demo2</div>;
};
